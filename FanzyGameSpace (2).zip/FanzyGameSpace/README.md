# Fanzy Game Space

Kotlin + Jetpack Compose (Material 3). AGP 8.5.2, Kotlin 1.9.24, Compose compiler 1.5.14, Gradle 8.7, JDK 17.

## Build
1. Buka folder ini di Android Studio (Koala / Ladybug) -> Sync -> Run.
   ATAU via terminal (butuh internet + JDK 17 + Android SDK 34):
2. `gradle wrapper --gradle-version 8.7`  (sekali saja, untuk bikin gradle/wrapper/gradle-wrapper.jar)
3. `./gradlew assembleDebug`

## Pakai
- Install Shizuku & start service-nya (Wireless debugging / root). Buka Fanzy -> pop-up izin Shizuku muncul otomatis.
- Overlay: izinkan "Tampil di atas aplikasi lain". Makro: aktifkan Aksesibilitas "Fanzy Game Space" (opsional, fallback ke Shizuku input tap).
- Developer Key: FANZYDEV2026
- `cmd game downscale/mode` butuh Android 12+.

## APK tanpa Android Studio
Upload folder ini ke repo GitHub -> tab Actions -> "Build APK" -> download artifact `FanzyGameSpace-debug-apk`.
