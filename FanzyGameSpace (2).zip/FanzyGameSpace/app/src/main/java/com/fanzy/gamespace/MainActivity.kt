package com.fanzy.gamespace

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.fanzy.gamespace.ui.FanzyTheme
import com.fanzy.gamespace.ui.HomeScreen

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        // Auto pop-up izin resmi Shizuku saat app dibuka
        ShizukuHelper.init()
        setContent { FanzyTheme { HomeScreen(vm) } }
    }

    override fun onResume() {
        super.onResume()
        ShizukuHelper.refresh(autoRequest = false)
        vm.syncPrefs()
    }

    override fun onDestroy() {
        ShizukuHelper.release()
        super.onDestroy()
    }
}
