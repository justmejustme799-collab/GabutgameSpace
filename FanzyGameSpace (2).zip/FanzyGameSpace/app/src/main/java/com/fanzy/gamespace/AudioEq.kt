package com.fanzy.gamespace

import android.media.audiofx.Equalizer

/** Footstep EQ: angkat frekuensi 1–8 kHz (langkah kaki), tahan bass. */
object AudioEq {
    private var eq: Equalizer? = null

    fun set(on: Boolean): Boolean {
        return try {
            if (on) {
                eq?.release()
                val e = Equalizer(0, 0)
                val range = e.bandLevelRange
                val lo = range[0]
                val hi = range[1]
                for (b in 0 until e.numberOfBands.toInt()) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000
                    val level = when {
                        hz < 250 -> (lo / 2).toShort()
                        hz in 1000..8000 -> hi
                        else -> 0.toShort()
                    }
                    e.setBandLevel(b.toShort(), level)
                }
                e.enabled = true
                eq = e
            } else {
                eq?.enabled = false
                eq?.release()
                eq = null
            }
            true
        } catch (t: Throwable) {
            false
        }
    }
}
