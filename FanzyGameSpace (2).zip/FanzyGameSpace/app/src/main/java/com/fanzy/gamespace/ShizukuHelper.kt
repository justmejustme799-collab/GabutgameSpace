package com.fanzy.gamespace

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_RUNNING, NEED_PERMISSION, CONNECTED }

data class ShellResult(val code: Int, val out: String, val err: String) {
    val ok: Boolean get() = code == 0
}

object ShizukuHelper {
    const val REQ_CODE = 1001

    private val _state = MutableStateFlow(ShizukuState.NOT_RUNNING)
    val state: StateFlow<ShizukuState> = _state.asStateFlow()
    private var inited = false

    private val onBinder = Shizuku.OnBinderReceivedListener { refresh(autoRequest = true) }
    private val onDead = Shizuku.OnBinderDeadListener { refresh(autoRequest = false) }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh(autoRequest = false) }

    /** Panggil saat app dibuka: pasang listener + langsung munculkan pop-up izin Shizuku. */
    fun init() {
        if (inited) { refresh(autoRequest = true); return }
        inited = true
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        refresh(autoRequest = true)
    }

    fun release() {
        if (!inited) return
        inited = false
        try {
            Shizuku.removeBinderReceivedListener(onBinder)
            Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onPerm)
        } catch (e: Throwable) { /* ignore */ }
    }

    val isConnected: Boolean
        get() = try {
            Shizuku.pingBinder() && !Shizuku.isPreV11() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) { false }

    fun refresh(autoRequest: Boolean) {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
                _state.value = ShizukuState.NOT_RUNNING
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                _state.value = ShizukuState.CONNECTED
            } else {
                _state.value = ShizukuState.NEED_PERMISSION
                if (autoRequest) Shizuku.requestPermission(REQ_CODE)
            }
        } catch (e: Throwable) {
            _state.value = ShizukuState.NOT_RUNNING
        }
    }

    /** Munculkan pop-up izin resmi Shizuku. false = Shizuku belum jalan. */
    fun requestPermission(): Boolean = try {
        if (!Shizuku.pingBinder()) {
            false
        } else {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) refresh(false)
            else Shizuku.requestPermission(REQ_CODE)
            true
        }
    } catch (e: Throwable) { false }

    /** Tombol "Connect Shizuku": pop-up izin, atau buka app Shizuku kalau belum aktif. */
    fun connect(ctx: Context): String {
        if (requestPermission()) return "Pop-up izin Shizuku dikirim"
        val launch = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        return if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(launch)
            "Shizuku belum aktif — start dulu service-nya, lalu balik ke sini"
        } else {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            "Shizuku belum terinstall"
        }
    }

    /** Eksekusi shell nyata via Shizuku.newProcess (private di API 13 → pakai reflection). */
    fun exec(command: String): ShellResult {
        if (!isConnected) return ShellResult(-1, "", "Shizuku belum terhubung")
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            val code = p.waitFor()
            ShellResult(code, out.trim(), err.trim())
        } catch (e: Throwable) {
            ShellResult(-2, "", e.cause?.message ?: e.message ?: "error")
        }
    }

    suspend fun run(command: String): ShellResult = withContext(Dispatchers.IO) { exec(command) }
}
