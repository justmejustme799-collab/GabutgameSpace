package com.fanzy.gamespace.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.view.View

/** Background sudut miring (chamfered cyberpunk) untuk view overlay. */
class ChamferDrawable(
    private val fill: Int,
    private val stroke: Int,
    private val cut: Float,
    private val strokeW: Float
) : Drawable() {
    private val paintF = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = fill }
    private val paintS = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = stroke; strokeWidth = strokeW }
    private val path = Path()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val i = strokeW / 2f
        val l = bounds.left + i
        val t = bounds.top + i
        val r = bounds.right - i
        val b = bounds.bottom - i
        path.reset()
        path.moveTo(l + cut, t)
        path.lineTo(r, t)
        path.lineTo(r, b - cut)
        path.lineTo(r - cut, b)
        path.lineTo(l, b)
        path.lineTo(l, t + cut)
        path.close()
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, paintF)
        canvas.drawPath(path, paintS)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Titik bidik '+' neon di tengah layar. */
class CrosshairView(ctx: Context, var color: Int) : View(ctx) {
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val arm = 14f * d
        val gap = 3f * d
        glow.color = (color and 0x00FFFFFF) or 0x55000000
        glow.strokeWidth = 6f * d
        core.color = color
        core.strokeWidth = 2f * d
        for (p in listOf(glow, core)) {
            canvas.drawLine(cx - arm, cy, cx - gap, cy, p)
            canvas.drawLine(cx + gap, cy, cx + arm, cy, p)
            canvas.drawLine(cx, cy - arm, cx, cy - gap, p)
            canvas.drawLine(cx, cy + gap, cx, cy + arm, p)
        }
    }
}
