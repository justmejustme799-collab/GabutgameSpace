package com.fanzy.gamespace.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

@Composable
fun AdDialog(onClaim: () -> Unit, onClose: () -> Unit) {
    var left by remember { mutableIntStateOf(5) }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left -= 1
        }
    }
    Dialog(
        onDismissRequest = { if (left == 0) onClose() },
        properties = DialogProperties(dismissOnClickOutside = false)
    ) {
        ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Gold, glow = true) {
            T("📺 IKLAN SPONSOR", 14, Fz.Gold, FontWeight.Black, spacing = 1.5f)
            Spacer(Modifier.height(8.dp))
            T("Nonton sampai habis buat dapet +2 Token", 12, Fz.Dim)
            Spacer(Modifier.height(10.dp))
            RotGauge(
                value = (5 - left) / 5f,
                centerText = if (left > 0) "$left" else "OK",
                label = if (left > 0) "tunggu..." else "selesai!",
                color = Fz.Gold,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            GlowButton("KLAIM +2 TOKEN", Modifier.fillMaxWidth(), Fz.Green, enabled = left == 0) { onClaim() }
            Spacer(Modifier.height(8.dp))
            GlowButton("TUTUP", Modifier.fillMaxWidth(), Fz.Dim, pulse = false) { onClose() }
        }
    }
}

@Composable
fun DevKeyDialog(onSubmit: (String) -> Boolean, onClose: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onClose) {
        ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Gold, glow = true) {
            T("🔑 DEVELOPER KEY", 14, Fz.Gold, FontWeight.Black, spacing = 1.5f)
            Spacer(Modifier.height(8.dp))
            T("Masukin password buat buka ROG DEV VIP (unlimited, tanpa iklan).", 12, Fz.Dim)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = pw,
                onValueChange = { pw = it; err = false },
                singleLine = true,
                label = { T("Password", 12, Fz.Dim) },
                visualTransformation = PasswordVisualTransformation(),
                isError = err,
                modifier = Modifier.fillMaxWidth()
            )
            if (err) T("Password salah bro 😅", 11, Fz.Red)
            Spacer(Modifier.height(10.dp))
            GlowButton("BUKA VIP", Modifier.fillMaxWidth(), Fz.Gold) { err = !onSubmit(pw) }
            Spacer(Modifier.height(8.dp))
            GlowButton("BATAL", Modifier.fillMaxWidth(), Fz.Dim, pulse = false) { onClose() }
        }
    }
}

@Composable
fun InfoDialog(title: String, body: String, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose) {
        ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Cyan, glow = true) {
            T(title.uppercase(), 14, Fz.Cyan, FontWeight.Black, spacing = 1f)
            Spacer(Modifier.height(10.dp))
            T(body, 13, mono = true)
            Spacer(Modifier.height(12.dp))
            GlowButton("OK", Modifier.fillMaxWidth(), Fz.Cyan, pulse = false) { onClose() }
        }
    }
}

@Composable
fun MacroDialog(initialDelay: Int, initialCombo: Boolean, onSave: (Int, Boolean) -> Unit, onClose: () -> Unit) {
    var delayMs by remember { mutableFloatStateOf(initialDelay.toFloat()) }
    var combo by remember { mutableStateOf(initialCombo) }
    Dialog(onDismissRequest = onClose) {
        ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Red, glow = true) {
            T("🖱️ MACRO CONFIGURATOR", 14, Fz.Red, FontWeight.Black, spacing = 1f)
            Spacer(Modifier.height(10.dp))
            T("Delay antar tap: ${delayMs.toInt()} ms", 12, Fz.Cyan, mono = true)
            Slider(value = delayMs, onValueChange = { delayMs = it }, valueRange = 50f..1000f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChamferCard(Modifier.weight(1f), accent = if (!combo) Fz.Cyan else Fz.Dim, glow = !combo, cut = 8.dp, onClick = { combo = false }) {
                    T("AUTO-TAP", 12, androidx.compose.ui.graphics.Color.White, FontWeight.Bold, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    T("1 titik", 10, Fz.Dim, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
                ChamferCard(Modifier.weight(1f), accent = if (combo) Fz.Cyan else Fz.Dim, glow = combo, cut = 8.dp, onClick = { combo = true }) {
                    T("COMBO", 12, androidx.compose.ui.graphics.Color.White, FontWeight.Bold, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    T("urut 1→N", 10, Fz.Dim, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
            Spacer(Modifier.height(12.dp))
            GlowButton("SIMPAN", Modifier.fillMaxWidth(), Fz.Green) { onSave(delayMs.toInt(), combo) }
            Spacer(Modifier.height(8.dp))
            GlowButton("BATAL", Modifier.fillMaxWidth(), Fz.Dim, pulse = false) { onClose() }
        }
    }
}
