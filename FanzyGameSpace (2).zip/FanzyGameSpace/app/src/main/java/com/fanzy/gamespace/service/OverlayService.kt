package com.fanzy.gamespace.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.fanzy.gamespace.MainActivity
import com.fanzy.gamespace.McScale
import com.fanzy.gamespace.Prefs
import com.fanzy.gamespace.R
import com.fanzy.gamespace.ShizukuHelper
import com.fanzy.gamespace.SystemInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
        private const val CH = "fanzy_overlay"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var ball: TextView? = null
    private var panel: LinearLayout? = null
    private var crosshair: CrosshairView? = null
    private var crossState = 0
    private val targets = mutableListOf<TextView>()
    private var macroJob: Job? = null

    private lateinit var tvStats: TextView
    private lateinit var tvDelay: TextView
    private lateinit var btnStart: TextView
    private lateinit var btnMode: TextView
    private lateinit var btnCross: TextView
    private lateinit var btnBright: TextView

    private var screenW = 0
    private var screenH = 0
    private val panelW get() = dp(264)

    private val RED = Color.parseColor("#FF1E42")
    private val CYAN = Color.parseColor("#00E5FF")
    private val GREEN = Color.parseColor("#39FF88")
    private val PANEL_BG = Color.parseColor("#EE0B0C12")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        startAsForeground()
        buildBall()
        buildPanel()
        startStats()
    }

    override fun onDestroy() {
        running = false
        macroJob?.cancel()
        scope.cancel()
        listOfNotNull<View>(ball, panel, crosshair).forEach { safeRemove(it) }
        targets.forEach { safeRemove(it) }
        targets.clear()
        super.onDestroy()
    }

    // ---------- helpers ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun safeRemove(v: View) {
        try { wm.removeView(v) } catch (e: Exception) { /* sudah dihapus */ }
    }

    private val overlayType: Int
        get() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private val baseFlags: Int
        get() = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private fun lp(w: Int, h: Int, flags: Int, gravity: Int = Gravity.TOP or Gravity.START): WindowManager.LayoutParams =
        WindowManager.LayoutParams(w, h, overlayType, flags, PixelFormat.TRANSLUCENT).apply { this.gravity = gravity }

    private fun startAsForeground() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH, "Fanzy Overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Fanzy Game Space")
            .setContentText("Game Genie overlay aktif")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun tv(label: String, size: Float = 12f, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = label
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun btn(label: String, color: Int, onClick: () -> Unit): TextView =
        tv(label, 11f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(9), dp(6), dp(9))
            background = ChamferDrawable((color and 0x00FFFFFF) or 0x33000000, color, dp(6).toFloat(), dp(1).toFloat())
            setOnClickListener { onClick() }
        }

    private fun section(label: String): TextView =
        tv("◢ $label", 10f, CYAN, true).apply { setPadding(dp(2), dp(10), 0, dp(3)) }

    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { v ->
            addView(
                v,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                }
            )
        }
    }

    private fun makeDraggable(handle: View, target: View, onClick: (() -> Unit)? = null, onRelease: (() -> Unit)? = null) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            val p = target.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    if (moved) {
                        p.x = ox + dx
                        p.y = oy + dy
                        wm.updateViewLayout(target, p)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) onRelease?.invoke() else onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Magic Floating Ball ----------
    private fun buildBall() {
        val b = tv("F", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#EE12141C"))
                setStroke(dp(2), RED)
            }
        }
        val p = lp(dp(52), dp(52), baseFlags)
        p.x = 0
        p.y = screenH / 3
        makeDraggable(b, b, onClick = { showPanel() }, onRelease = { snapBall() })
        wm.addView(b, p)
        ball = b
    }

    private fun snapBall() {
        val b = ball ?: return
        val p = b.layoutParams as WindowManager.LayoutParams
        p.x = if (p.x + dp(26) < screenW / 2) 0 else screenW - dp(52)
        wm.updateViewLayout(b, p)
    }

    private fun showPanel() {
        val b = ball ?: return
        val pn = panel ?: return
        val bp = b.layoutParams as WindowManager.LayoutParams
        val pp = pn.layoutParams as WindowManager.LayoutParams
        pp.x = (if (bp.x < screenW / 2) dp(6) else screenW - panelW - dp(6))
        pp.y = (bp.y - dp(40)).coerceAtMost(screenH / 3).coerceAtLeast(dp(24))
        pn.visibility = View.VISIBLE
        b.visibility = View.GONE
        wm.updateViewLayout(pn, pp)
    }

    private fun minimize() {
        val b = ball ?: return
        val pn = panel ?: return
        val bp = b.layoutParams as WindowManager.LayoutParams
        val pp = pn.layoutParams as WindowManager.LayoutParams
        bp.x = if (pp.x + panelW / 2 < screenW / 2) 0 else screenW - dp(52)
        bp.y = pp.y
        pn.visibility = View.GONE
        b.visibility = View.VISIBLE
        wm.updateViewLayout(b, bp)
    }

    // ---------- Sidebar Panel ----------
    private fun buildPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ChamferDrawable(PANEL_BG, RED, dp(14).toFloat(), dp(2).toFloat())
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = tv("◢ FANZY GAME GENIE", 13f, RED, true)
        val min = tv("—", 20f, CYAN, true).apply {
            setPadding(dp(14), 0, dp(4), 0)
            setOnClickListener { minimize() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(min)
        root.addView(header)

        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Telemetri
        c.addView(section("TELEMETRI REAL-TIME"))
        tvStats = tv("...", 12f, Color.WHITE, true)
        c.addView(tvStats)

        // MC Graphics
        c.addView(section("GRAFIK MC (SHIZUKU)"))
        c.addView(row(
            btn("MC 30% EXTREME", RED) { applyScale(McScale.EXTREME) },
            btn("NORMAL 100%", CYAN) { applyScale(McScale.NORMAL) }
        ))

        // Crosshair
        c.addView(section("CUSTOM CROSSHAIR"))
        btnCross = btn("CROSSHAIR: OFF", CYAN) { cycleCrosshair() }
        c.addView(row(btnCross))

        // Macro
        c.addView(section("MAKRO AUTO-TAP / COMBO"))
        c.addView(row(
            btn("+ TITIK", GREEN) { addTarget() },
            btn("HAPUS", RED) { clearTargets() }
        ))
        tvDelay = tv("${Prefs.macroDelay} ms", 12f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        c.addView(row(
            btn("−", CYAN) { changeDelay(-1) },
            tvDelay,
            btn("+", CYAN) { changeDelay(1) }
        ))
        btnMode = btn(modeLabel(), CYAN) { toggleMacroMode() }
        c.addView(row(btnMode))
        btnStart = btn("▶ START", GREEN) { toggleMacro() }
        c.addView(row(btnStart))

        // Quick tools
        c.addView(section("QUICK TOOLS"))
        btnBright = btn(brightLabel(), CYAN) { toggleBrightness() }
        c.addView(row(
            btn("RAM BOOST", RED) { quickRamBoost() },
            btnBright
        ))

        val maxH = minOf(dp(430), (screenH * 0.65f).toInt())
        val sv = ScrollView(this).apply { addView(c) }
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH))

        val p = lp(panelW, WindowManager.LayoutParams.WRAP_CONTENT, baseFlags)
        p.x = dp(6)
        p.y = dp(60)
        root.visibility = View.GONE
        makeDraggable(header, root)
        wm.addView(root, p)
        panel = root
    }

    private fun startStats() {
        scope.launch {
            while (isActive) {
                val t = SystemInfo.batteryTempC(this@OverlayService)
                val r = SystemInfo.freeRamMb(this@OverlayService)
                tvStats.text = String.format(Locale.US, "🌡 %.1f°C   🧠 %d MB free", t, r)
                delay(2000)
            }
        }
    }

    // ---------- Grafik MC ----------
    private fun applyScale(s: McScale) {
        if (!ShizukuHelper.isConnected) { toast("Shizuku belum terhubung — buka app Fanzy"); return }
        if (s != McScale.NORMAL && !Prefs.consumeToken()) {
            toast("Token habis — buka app → Tonton Iklan")
            return
        }
        scope.launch {
            val r = ShizukuHelper.run(s.command(Prefs.gamePkg))
            toast(if (r.ok) "Grafik ${s.label} aktif" else "Gagal: ${r.err.take(60)}")
        }
    }

    // ---------- Crosshair ----------
    private fun cycleCrosshair() {
        crossState = (crossState + 1) % 3
        if (crossState == 0) {
            crosshair?.let { safeRemove(it) }
            crosshair = null
            btnCross.text = "CROSSHAIR: OFF"
            return
        }
        val col = if (crossState == 1) RED else GREEN
        val existing = crosshair
        if (existing == null) {
            val v = CrosshairView(this, col)
            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            wm.addView(v, lp(dp(48), dp(48), flags, Gravity.CENTER))
            crosshair = v
        } else {
            existing.color = col
            existing.invalidate()
        }
        btnCross.text = if (crossState == 1) "CROSSHAIR: MERAH" else "CROSSHAIR: HIJAU"
    }

    // ---------- Macro ----------
    private fun modeLabel() = if (Prefs.macroCombo) "MODE: COMBO (1→N)" else "MODE: AUTO-TAP (titik 1)"

    private fun toggleMacroMode() {
        Prefs.macroCombo = !Prefs.macroCombo
        btnMode.text = modeLabel()
    }

    private fun changeDelay(dir: Int) {
        val step = if (Prefs.macroDelay >= 200) 50 else 25
        Prefs.macroDelay = Prefs.macroDelay + dir * step
        tvDelay.text = "${Prefs.macroDelay} ms"
    }

    private fun addTarget() {
        if (macroJob != null) { toast("Stop makro dulu"); return }
        val idx = targets.size + 1
        val t = tv("$idx", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#66FF1E42"))
                setStroke(dp(2), CYAN)
            }
        }
        val p = lp(dp(46), dp(46), baseFlags)
        p.x = screenW / 2 - dp(23) + (idx - 1) * dp(12)
        p.y = (screenH / 2 - dp(23) + (idx - 1) * dp(56)).coerceAtMost(screenH - dp(80))
        makeDraggable(t, t)
        wm.addView(t, p)
        targets.add(t)
        toast("Titik $idx — geser ke posisi tombol game")
    }

    private fun clearTargets() {
        stopMacro()
        targets.forEach { safeRemove(it) }
        targets.clear()
    }

    private fun setTargetsTouchable(touchable: Boolean) {
        targets.forEach { t ->
            val p = t.layoutParams as WindowManager.LayoutParams
            p.flags = if (touchable) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { wm.updateViewLayout(t, p) } catch (e: Exception) { /* ignore */ }
        }
    }

    private fun toggleMacro() {
        if (macroJob != null) stopMacro() else startMacro()
    }

    private fun startMacro() {
        if (targets.isEmpty()) { toast("Tambah titik dulu (+ TITIK)"); return }
        if (FanzyAccessibilityService.instance == null && !ShizukuHelper.isConnected) {
            toast("Aktifkan Aksesibilitas Fanzy atau sambungkan Shizuku")
            return
        }
        if (!Prefs.consumeToken()) { toast("Token habis — buka app → Tonton Iklan"); return }
        setTargetsTouchable(false)
        btnStart.text = "■ STOP"
        macroJob = scope.launch {
            while (isActive) {
                val list = if (Prefs.macroCombo) targets.toList() else listOf(targets.first())
                for (t in list) {
                    if (!isActive) break
                    val loc = IntArray(2)
                    t.getLocationOnScreen(loc)
                    doTap(loc[0] + t.width / 2, loc[1] + t.height / 2)
                    delay(Prefs.macroDelay.toLong())
                }
            }
        }
    }

    private fun stopMacro() {
        macroJob?.cancel()
        macroJob = null
        setTargetsTouchable(true)
        if (::btnStart.isInitialized) btnStart.text = "▶ START"
    }

    private suspend fun doTap(x: Int, y: Int) {
        val acc = FanzyAccessibilityService.instance
        if (acc != null) {
            acc.tap(x.toFloat(), y.toFloat())
        } else {
            withContext(Dispatchers.IO) { ShizukuHelper.exec("input tap $x $y") }
        }
    }

    // ---------- Quick tools ----------
    private fun quickRamBoost() {
        if (!ShizukuHelper.isConnected) { toast("Shizuku belum terhubung"); return }
        scope.launch {
            val before = SystemInfo.freeRamMb(this@OverlayService)
            ShizukuHelper.run("am kill-all")
            delay(900)
            val after = SystemInfo.freeRamMb(this@OverlayService)
            toast("RAM: $before MB → $after MB")
        }
    }

    private fun brightLabel() = if (Prefs.flag("bright")) "BRIGHT LOCK: ON" else "BRIGHT LOCK: OFF"

    private fun toggleBrightness() {
        if (!ShizukuHelper.isConnected) { toast("Shizuku belum terhubung"); return }
        val want = !Prefs.flag("bright")
        scope.launch {
            ShizukuHelper.run("settings put system screen_brightness_mode ${if (want) 0 else 1}")
            Prefs.setFlag("bright", want)
            btnBright.text = brightLabel()
        }
    }
}
