package com.fanzy.gamespace

import android.app.Application

class FanzyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}
