package com.fanzy.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager

data class Telemetry(
    val tempC: Float = 0f,
    val battery: Int = 0,
    val freeRamMb: Long = 0,
    val totalRamMb: Long = 1,
    val netLabel: String = "-",
    val netMbps: Int = 0
)

object SystemInfo {
    fun batteryTempC(ctx: Context): Float {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    fun batteryLevel(ctx: Context): Int {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    }

    private fun memInfo(ctx: Context): ActivityManager.MemoryInfo {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi
    }

    fun freeRamMb(ctx: Context): Long = memInfo(ctx).availMem / (1024 * 1024)
    fun totalRamMb(ctx: Context): Long = memInfo(ctx).totalMem / (1024 * 1024)

    fun network(ctx: Context): Pair<String, Int> {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork ?: return "Offline" to 0
            val caps = cm.getNetworkCapabilities(net) ?: return "Offline" to 0
            val label = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Seluler"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "LAN"
                else -> "Net"
            }
            label to (caps.linkDownstreamBandwidthKbps / 1000)
        } catch (e: Exception) {
            "N/A" to 0
        }
    }

    fun snapshot(ctx: Context): Telemetry {
        val (label, mbps) = network(ctx)
        return Telemetry(
            tempC = batteryTempC(ctx),
            battery = batteryLevel(ctx),
            freeRamMb = freeRamMb(ctx),
            totalRamMb = totalRamMb(ctx).coerceAtLeast(1),
            netLabel = label,
            netMbps = mbps
        )
    }
}
