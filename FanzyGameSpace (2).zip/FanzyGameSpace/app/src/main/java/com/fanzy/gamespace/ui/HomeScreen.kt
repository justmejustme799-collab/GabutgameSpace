package com.fanzy.gamespace.ui

import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fanzy.gamespace.GameInfo
import com.fanzy.gamespace.Games
import com.fanzy.gamespace.MainViewModel
import com.fanzy.gamespace.McScale
import com.fanzy.gamespace.PerfMode
import com.fanzy.gamespace.ShizukuHelper
import com.fanzy.gamespace.ShizukuState
import com.fanzy.gamespace.Tools

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val shz by ShizukuHelper.state.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        vm.msg.collect { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
    }

    Box(Modifier.fillMaxSize().background(Fz.Bg).systemBarsPadding()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Header(shz, vm) }
            item { AccessBar(vm) }
            item { Hero(vm) }
            item { ModeRow(vm) }
            item { TelemetryPanel(vm) }
            item { McPanel(vm) }
            item { OverlayPanel(vm) }
            item { ToolsGrid(vm) }
            item { Console(vm) }
        }
    }

    if (vm.showAd) AdDialog(onClaim = { vm.claimAd() }, onClose = { vm.showAd = false })
    if (vm.showDev) DevKeyDialog(onSubmit = { vm.tryDevKey(it) }, onClose = { vm.showDev = false })
    if (vm.showMacro) MacroDialog(vm.macroDelay, vm.macroCombo, { d, c -> vm.saveMacro(d, c) }, { vm.showMacro = false })
    vm.info?.let { (title, body) -> InfoDialog(title, body) { vm.info = null } }
}

@Composable
private fun Header(shz: ShizukuState, vm: MainViewModel) {
    val (label, col) = when (shz) {
        ShizukuState.CONNECTED -> "SHIZUKU CONNECTED" to Fz.Green
        ShizukuState.NEED_PERMISSION -> "SHIZUKU: BUTUH IZIN" to Fz.Gold
        ShizukuState.NOT_RUNNING -> "SHIZUKU DISCONNECTED" to Fz.Red
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row {
            T("FANZY ", 24, Fz.Red, FontWeight.Black, spacing = 2f)
            T("GAME SPACE", 24, Fz.Cyan, FontWeight.Black)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(col))
            Spacer(Modifier.width(8.dp))
            T(label, 11, col, FontWeight.Bold, Modifier.weight(1f), mono = true)
            ChamferCard(accent = if (vm.isVip) Fz.Gold else Fz.Cyan, cut = 8.dp, onClick = {
                if (vm.isVip) vm.info = "ROG DEV VIP" to "Mode VIP aktif.\nToken unlimited, tanpa iklan." else vm.showDev = true
            }) {
                T(if (vm.isVip) "👑 ROG DEV VIP" else "⚙ MODE DEVELOPER", 11, if (vm.isVip) Fz.Gold else Fz.Cyan, FontWeight.Bold)
            }
        }
        if (shz != ShizukuState.CONNECTED) {
            val ctx = LocalContext.current
            GlowButton("CONNECT SHIZUKU", Modifier.fillMaxWidth(), Fz.Red) { vm.connectShizuku() }
        }
    }
}

@Composable
private fun AccessBar(vm: MainViewModel) {
    if (vm.isVip) {
        ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Gold, glow = true) {
            T("👑 ROG DEV VIP — UNLIMITED • NO ADS", 13, Fz.Gold, FontWeight.Black, spacing = 1f)
        }
    } else {
        ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Cyan) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("TOKEN: ${vm.tokens}", 18, Fz.Cyan, FontWeight.Black, mono = true)
                    T("MC Grafik / Makro = 1 token", 10, Fz.Dim)
                }
                GlowButton("📺 Tonton Iklan (+2 Token)", Modifier.weight(1.3f), Fz.Gold, pulse = false) { vm.showAd = true }
            }
        }
    }
}

@Composable
private fun Hero(vm: MainViewModel) {
    val pager = rememberPagerState(initialPage = vm.gameIndex, pageCount = { Games.list.size })
    LaunchedEffect(pager.currentPage) { vm.selectGame(pager.currentPage) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        HorizontalPager(
            state = pager,
            contentPadding = PaddingValues(end = 28.dp),
            pageSpacing = 10.dp
        ) { page -> GameCard(Games.list[page]) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            repeat(Games.list.size) { i ->
                val on = i == pager.currentPage
                Box(
                    Modifier
                        .padding(3.dp)
                        .size(if (on) 18.dp else 6.dp, 6.dp)
                        .background(if (on) Fz.Red else Fz.Dim, RoundedCornerShape(3.dp))
                )
            }
        }
        GlowButton("⚡ TURBO BOOST & LAUNCH", Modifier.fillMaxWidth(), Fz.Red) { vm.turboLaunch() }
    }
}

@Composable
private fun GameCard(g: GameInfo) {
    val inf = rememberInfiniteTransition(label = "ring")
    val rot by inf.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "ringRot"
    )
    ChamferCard(Modifier.fillMaxWidth().height(180.dp), accent = g.c1, cut = 22.dp, glow = true) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(listOf(g.c1.copy(alpha = 0.35f), Color.Transparent)))
        ) {
            Canvas(Modifier.size(110.dp).align(Alignment.TopEnd)) {
                rotate(rot) {
                    arcRing(g.c2, 0f, 80f, 4.dp.toPx(), 6.dp.toPx())
                    arcRing(g.c1, 180f, 80f, 4.dp.toPx(), 6.dp.toPx())
                    arcRing(Color.White.copy(alpha = 0.3f), 90f, 40f, 2.dp.toPx(), 16.dp.toPx())
                }
            }
            Column(Modifier.align(Alignment.BottomStart)) {
                T(g.tag, 11, g.c2, FontWeight.Bold, mono = true, spacing = 2f)
                T(g.name, 28, Color.White, FontWeight.Black)
                T(g.pkg, 10, Fz.Dim, mono = true)
            }
        }
    }
}

@Composable
private fun ModeRow(vm: MainViewModel) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PerfMode.values().forEach { m ->
            val sel = vm.mode == m
            ChamferCard(Modifier.weight(1f), accent = m.color, glow = sel, cut = 10.dp, onClick = { vm.applyMode(m) }) {
                T(m.icon, 22, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
                T(m.title, 12, if (sel) m.color else Color.White, FontWeight.Black, Modifier.fillMaxWidth(), TextAlign.Center)
                T(m.sub, 9, Fz.Dim, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun TelemetryPanel(vm: MainViewModel) {
    val t = vm.telemetry
    ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Cyan) {
        T("HARDWARE TELEMETRY", 12, Fz.Cyan, FontWeight.Black, spacing = 1.5f)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RotGauge(
                value = t.tempC / 60f,
                centerText = "%.1f°".format(t.tempC),
                label = "SUHU BATERAI",
                color = if (t.tempC >= 40f) Fz.Red else Fz.Cyan,
                modifier = Modifier.weight(1f),
                dimension = 100.dp
            )
            RotGauge(
                value = t.freeRamMb.toFloat() / t.totalRamMb.toFloat(),
                centerText = "${t.freeRamMb}",
                label = "RAM FREE (MB)",
                color = Fz.Green,
                modifier = Modifier.weight(1f),
                dimension = 100.dp
            )
            RotGauge(
                value = t.netMbps / 100f,
                centerText = "${t.netMbps}",
                label = "${t.netLabel} Mbps",
                color = Fz.Gold,
                modifier = Modifier.weight(1f),
                dimension = 100.dp
            )
        }
    }
}

@Composable
private fun McPanel(vm: MainViewModel) {
    ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Red) {
        T("MC GRAPHICS ENGINE (SHIZUKU DOWNSCALE)", 12, Fz.Red, FontWeight.Black, spacing = 1f)
        T("Target: ${vm.game.name} • aktivasi = 1 token", 10, Fz.Dim)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            McScale.values().toList().chunked(2).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { s ->
                        val sel = vm.scale == s
                        ChamferCard(Modifier.weight(1f), accent = if (sel) Fz.Cyan else Fz.Dim, glow = sel, cut = 8.dp, onClick = { vm.applyScale(s) }) {
                            T("${s.pct}%", 20, if (sel) Fz.Cyan else Color.White, FontWeight.Black, mono = true)
                            T(s.label, 10, Fz.Dim)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        T("$ " + vm.scale.command(vm.game.pkg), 9, Fz.Dim, mono = true)
    }
}

@Composable
private fun OverlayPanel(vm: MainViewModel) {
    ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Red, glow = vm.overlayOn) {
        T("FLOATING GAME GENIE OVERLAY", 12, Fz.Red, FontWeight.Black, spacing = 1f)
        T("Sidebar • Magic Ball • Crosshair • Makro Auto-Tap/Combo", 10, Fz.Dim)
        Spacer(Modifier.height(8.dp))
        GlowButton(
            if (vm.overlayOn) "■ MATIKAN OVERLAY" else "▶ AKTIFKAN OVERLAY",
            Modifier.fillMaxWidth(),
            if (vm.overlayOn) Fz.Dim else Fz.Cyan,
            pulse = !vm.overlayOn
        ) { vm.toggleOverlay() }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            T(
                if (vm.accOn) "Aksesibilitas: ON ✔ (tap via dispatchGesture)" else "Aksesibilitas: OFF (tap lewat Shizuku)",
                10, if (vm.accOn) Fz.Green else Fz.Gold, modifier = Modifier.weight(1f), mono = true
            )
            ChamferCard(accent = Fz.Cyan, cut = 6.dp, onClick = { vm.openAccessibility() }) {
                T("BUKA", 10, Fz.Cyan, FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ToolsGrid(vm: MainViewModel) {
    ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Cyan) {
        T("12 PRO GAMING OPTIMIZER TOOLS", 12, Fz.Cyan, FontWeight.Black, spacing = 1f)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Tools.all.chunked(3).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { td ->
                        val on = vm.toolOn[td.id] == true || (td.id == "refresh" && vm.refreshHz != 0)
                        ChamferCard(
                            Modifier.weight(1f).height(96.dp),
                            accent = if (on) Fz.Cyan else Fz.Dim,
                            glow = on,
                            cut = 8.dp,
                            onClick = { vm.onTool(td.id) }
                        ) {
                            T(td.icon, 20, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
                            T(
                                if (td.id == "refresh" && vm.refreshHz != 0) "Refresh ${vm.refreshHz}Hz" else td.title,
                                10, if (on) Fz.Cyan else Color.White, FontWeight.Bold,
                                Modifier.fillMaxWidth(), TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Console(vm: MainViewModel) {
    ChamferCard(Modifier.fillMaxWidth(), accent = Fz.Dim) {
        T("SHIZUKU CONSOLE", 11, Fz.Dim, FontWeight.Bold, spacing = 1f)
        Spacer(Modifier.height(4.dp))
        if (vm.logs.isEmpty()) T("— belum ada aktivitas —", 10, Fz.Dim, mono = true)
        vm.logs.take(8).forEach { T(it, 9, Fz.Green, mono = true) }
    }
}
