package com.fanzy.gamespace.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text

object Fz {
    val Bg = Color(0xFF08090E)
    val Panel = Color(0xFF11131B)
    val Panel2 = Color(0xFF181B26)
    val Red = Color(0xFFFF1E42)
    val Cyan = Color(0xFF00E5FF)
    val Gold = Color(0xFFFFC21A)
    val Green = Color(0xFF39FF88)
    val Dim = Color(0xFF8A90A5)
}

@Composable
fun FanzyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Fz.Red,
            secondary = Fz.Cyan,
            background = Fz.Bg,
            surface = Fz.Panel,
            onPrimary = Color.White,
            onSecondary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun T(
    text: String,
    size: Int = 13,
    color: Color = Color.White,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    align: TextAlign? = null,
    mono: Boolean = false,
    spacing: Float = 0f
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size.sp,
        fontWeight = weight,
        fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default,
        letterSpacing = spacing.sp,
        textAlign = align
    )
}
