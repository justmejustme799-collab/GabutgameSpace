package com.fanzy.gamespace

import android.app.Application
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fanzy.gamespace.service.FanzyAccessibilityService
import com.fanzy.gamespace.service.OverlayService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Context get() = getApplication<Application>()

    var telemetry by mutableStateOf(Telemetry())
    var tokens by mutableIntStateOf(Prefs.tokens)
    var isVip by mutableStateOf(Prefs.isVip)
    var gameIndex by mutableIntStateOf(Games.list.indexOfFirst { it.pkg == Prefs.gamePkg }.coerceAtLeast(0))
    var mode by mutableStateOf(PerfMode.BALANCE)
    var scale by mutableStateOf(McScale.NORMAL)
    var refreshHz by mutableIntStateOf(0)
    var macroDelay by mutableIntStateOf(Prefs.macroDelay)
    var macroCombo by mutableStateOf(Prefs.macroCombo)
    var overlayOn by mutableStateOf(OverlayService.running)
    var accOn by mutableStateOf(FanzyAccessibilityService.instance != null)

    var showAd by mutableStateOf(false)
    var showDev by mutableStateOf(false)
    var showMacro by mutableStateOf(false)
    var info by mutableStateOf<Pair<String, String>?>(null)

    val toolOn = mutableStateMapOf<String, Boolean>().apply {
        Tools.toggles.forEach { put(it, Prefs.flag(it)) }
    }
    val logs = mutableStateListOf<String>()

    private val _msg = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val msg: SharedFlow<String> = _msg.asSharedFlow()

    private var lastGuard = 0L

    val game: GameInfo get() = Games.list[gameIndex]

    init {
        viewModelScope.launch {
            while (true) {
                refreshTelemetry()
                delay(2000)
            }
        }
    }

    // ---------- util ----------
    private fun log(line: String) {
        logs.add(0, line)
        while (logs.size > 40) logs.removeAt(logs.size - 1)
    }

    private fun say(text: String) {
        log(text)
        _msg.tryEmit(text)
    }

    fun syncPrefs() {
        tokens = Prefs.tokens
        isVip = Prefs.isVip
        macroDelay = Prefs.macroDelay
        macroCombo = Prefs.macroCombo
        overlayOn = OverlayService.running
        accOn = FanzyAccessibilityService.instance != null
        Tools.toggles.forEach { toolOn[it] = Prefs.flag(it) }
    }

    private fun refreshTelemetry() {
        val t = SystemInfo.snapshot(ctx)
        telemetry = t
        accOn = FanzyAccessibilityService.instance != null
        overlayOn = OverlayService.running
        val now = System.currentTimeMillis()
        if (toolOn["thermal"] == true && t.tempC >= 42f && now - lastGuard > 60_000 && ShizukuHelper.isConnected) {
            lastGuard = now
            viewModelScope.launch {
                sh("cmd game mode battery ${game.pkg}")
                mode = PerfMode.ECO
                say("🔥 Thermal Guard: ${t.tempC}°C → pindah ke Eco Mode")
            }
        }
    }

    private suspend fun sh(cmd: String): ShellResult {
        val r = ShizukuHelper.run(cmd)
        log("$ $cmd → " + if (r.ok) "OK" else "ERR ${r.err.take(70)}")
        return r
    }

    private fun requireShizuku(): Boolean {
        if (ShizukuHelper.isConnected) return true
        say("Shizuku belum terhubung — tekan CONNECT SHIZUKU")
        ShizukuHelper.requestPermission()
        return false
    }

    private fun consume(): Boolean {
        val ok = Prefs.consumeToken()
        syncPrefs()
        if (!ok) say("Token habis! Tonton iklan (+2) atau pakai Developer Key")
        return ok
    }

    // ---------- header / akses ----------
    fun connectShizuku() { say(ShizukuHelper.connect(ctx)) }

    fun selectGame(i: Int) {
        if (i !in Games.list.indices) return
        gameIndex = i
        Prefs.gamePkg = Games.list[i].pkg
    }

    fun claimAd() {
        Prefs.addTokens(2)
        syncPrefs()
        showAd = false
        say("+2 Token masuk, gaskeun!")
    }

    fun tryDevKey(input: String): Boolean {
        val ok = Prefs.verifyDevKey(input.trim())
        syncPrefs()
        if (ok) { showDev = false; say("ROG DEV VIP aktif — unlimited!") }
        return ok
    }

    fun saveMacro(delayMs: Int, combo: Boolean) {
        Prefs.macroDelay = delayMs
        Prefs.macroCombo = combo
        syncPrefs()
        showMacro = false
        say("Makro tersimpan: ${Prefs.macroDelay} ms, ${if (combo) "Combo" else "Auto-Tap"}")
    }

    // ---------- mode & grafik ----------
    fun applyMode(m: PerfMode) {
        if (!requireShizuku()) return
        viewModelScope.launch {
            val r = sh("cmd game mode ${m.gameMode} ${game.pkg}")
            if (m == PerfMode.XMODE) sh("am kill-all")
            mode = m
            say("${m.title} aktif " + if (r.ok) "✔" else "(ditolak ROM, cek console)")
        }
    }

    fun applyScale(s: McScale) {
        if (!requireShizuku()) return
        if (s != McScale.NORMAL && !consume()) return
        viewModelScope.launch {
            val r = sh(s.command(game.pkg))
            if (r.ok) scale = s
            say("Grafik ${s.label} (${s.pct}%) " + if (r.ok) "aktif ✔" else "gagal")
        }
    }

    fun turboLaunch() {
        viewModelScope.launch {
            if (ShizukuHelper.isConnected) {
                sh("cmd game mode performance ${game.pkg}")
                sh("am kill-all")
                mode = PerfMode.XMODE
            } else {
                say("Shizuku off — launch tanpa boost sistem")
            }
            if (Settings.canDrawOverlays(ctx) && !OverlayService.running) {
                OverlayService.start(ctx)
                overlayOn = true
            }
            val i = ctx.packageManager.getLaunchIntentForPackage(game.pkg)
            if (i == null) {
                say("${game.name} belum terinstall")
            } else {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            }
        }
    }

    fun toggleOverlay() {
        if (OverlayService.running) {
            OverlayService.stop(ctx)
            overlayOn = false
        } else if (Settings.canDrawOverlays(ctx)) {
            OverlayService.start(ctx)
            overlayOn = true
        } else {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            say("Izinkan 'Tampil di atas aplikasi lain', lalu aktifkan overlay lagi")
        }
    }

    fun openAccessibility() {
        val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    // ---------- 12 tools ----------
    fun onTool(id: String) {
        viewModelScope.launch {
            when (id) {
                "ram" -> {
                    if (!requireShizuku()) return@launch
                    val before = SystemInfo.freeRamMb(ctx)
                    sh("am kill-all")
                    delay(900)
                    val after = SystemInfo.freeRamMb(ctx)
                    refreshTelemetry()
                    say("RAM Cleaner: $before MB → $after MB")
                }
                "touch" -> toggleShell(
                    id, "Touch Booster",
                    listOf("settings put secure long_press_timeout 250", "settings put secure multi_press_timeout 200"),
                    listOf("settings put secure long_press_timeout 400", "settings put secure multi_press_timeout 300")
                )
                "dns" -> toggleShell(
                    id, "DNS 1.1.1.1",
                    listOf("settings put global private_dns_mode hostname", "settings put global private_dns_specifier one.one.one.one"),
                    listOf("settings put global private_dns_mode opportunistic")
                )
                "refresh" -> {
                    if (!requireShizuku()) return@launch
                    val next = when (refreshHz) { 0 -> 60; 60 -> 90; 90 -> 120; else -> 0 }
                    if (next == 0) {
                        sh("settings delete system min_refresh_rate")
                        sh("settings delete system peak_refresh_rate")
                    } else {
                        sh("settings put system min_refresh_rate $next")
                        sh("settings put system peak_refresh_rate $next")
                    }
                    refreshHz = next
                    say(if (next == 0) "Refresh rate: AUTO" else "Refresh rate dikunci ${next}Hz")
                }
                "thermal" -> {
                    val want = !(toolOn[id] ?: false)
                    toolOn[id] = want
                    Prefs.setFlag(id, want)
                    say("Thermal Guard ${if (want) "ON (auto Eco di ≥42°C)" else "OFF"}")
                }
                "dnd" -> toggleShell(id, "Do Not Disturb", listOf("cmd notification set_dnd priority"), listOf("cmd notification set_dnd off"))
                "bright" -> toggleShell(
                    id, "Brightness Lock",
                    listOf("settings put system screen_brightness_mode 0"),
                    listOf("settings put system screen_brightness_mode 1")
                )
                "eq" -> {
                    val want = !(toolOn[id] ?: false)
                    if (AudioEq.set(want)) {
                        toolOn[id] = want
                        Prefs.setFlag(id, want)
                        say("Footstep EQ ${if (want) "ON" else "OFF"}")
                    } else {
                        say("EQ global tidak didukung di perangkat ini")
                    }
                }
                "gyro" -> calibrateGyro()
                "time" -> gameTime()
                "angle" -> toggleShell(
                    id, "ANGLE GPU",
                    listOf(
                        "settings put global angle_gl_driver_selection_pkgs ${game.pkg}",
                        "settings put global angle_gl_driver_selection_values angle"
                    ),
                    listOf(
                        "settings delete global angle_gl_driver_selection_pkgs",
                        "settings delete global angle_gl_driver_selection_values"
                    )
                )
                "macro" -> showMacro = true
            }
        }
    }

    private suspend fun toggleShell(id: String, name: String, on: List<String>, off: List<String>) {
        if (!requireShizuku()) return
        val want = !(toolOn[id] ?: false)
        (if (want) on else off).forEach { sh(it) }
        toolOn[id] = want
        Prefs.setFlag(id, want)
        say("$name ${if (want) "ON" else "OFF"}")
    }

    private suspend fun calibrateGyro() {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        if (sensor == null) { say("HP ini tidak punya gyroscope"); return }
        var sx = 0.0
        var sy = 0.0
        var sz = 0.0
        var n = 0
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                sx += e.values[0]; sy += e.values[1]; sz += e.values[2]; n++
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        say("Kalibrasi gyro 2 detik — taruh HP rata & diam")
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
        delay(2000)
        sm.unregisterListener(l)
        if (n == 0) { say("Tidak ada data sensor"); return }
        val bias = String.format(Locale.US, "X %.4f | Y %.4f | Z %.4f rad/s", sx / n, sy / n, sz / n)
        Prefs.gyroBias = bias
        info = "Gyroscope Calibrator" to "Sampel: $n\nBias tersimpan:\n$bias\n\nNilai mendekati 0 = sensor sehat."
    }

    private suspend fun gameTime() {
        if (!requireShizuku()) return
        sh("appops set ${ctx.packageName} GET_USAGE_STATS allow")
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis())
        val byPkg = HashMap<String, Long>()
        stats?.forEach { byPkg[it.packageName] = (byPkg[it.packageName] ?: 0L) + it.totalTimeInForeground }
        val body = Games.list.joinToString("\n") { g ->
            val min = (byPkg[g.pkg] ?: 0L) / 60000
            "${g.name}: ${min / 60}j ${min % 60}m"
        }
        info = "Game Time Tracker (hari ini)" to body
    }
}
