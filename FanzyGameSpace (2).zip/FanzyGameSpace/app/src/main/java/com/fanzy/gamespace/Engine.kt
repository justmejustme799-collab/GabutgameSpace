package com.fanzy.gamespace

import androidx.compose.ui.graphics.Color

data class GameInfo(val name: String, val pkg: String, val tag: String, val c1: Color, val c2: Color)

object Games {
    val list = listOf(
        GameInfo("Free Fire", "com.dts.freefireth", "BATTLE ROYALE", Color(0xFFFF6A00), Color(0xFFFF1E42)),
        GameInfo("Free Fire MAX", "com.dts.freefiremax", "ULTRA HD ROYALE", Color(0xFFFF1E42), Color(0xFFB000FF)),
        GameInfo("Mobile Legends", "com.mobile.legends", "MOBA 5V5", Color(0xFF00E5FF), Color(0xFF2962FF)),
        GameInfo("PUBG Mobile", "com.tencent.ig", "TACTICAL SHOOTER", Color(0xFFFFC21A), Color(0xFFFF1E42))
    )
}

/** Skala resolusi nyata via `cmd game downscale` (Android 12+). */
enum class McScale(val label: String, val pct: Int, private val value: String?) {
    NORMAL("Normal", 100, null),
    LITE("Lite HD", 70, "0.7"),
    POTATO("Potato", 50, "0.5"),
    EXTREME("Extreme MC Kotak-Kotak", 30, "0.3");

    fun command(pkg: String): String =
        if (value == null) "cmd game downscale disable $pkg" else "cmd game downscale $value $pkg"
}

enum class PerfMode(val title: String, val sub: String, val icon: String, val gameMode: String, val color: Color) {
    ECO("ECO", "Hemat baterai", "🍃", "battery", Color(0xFF39FF88)),
    BALANCE("BALANCE", "Seimbang", "⚖️", "standard", Color(0xFF00E5FF)),
    XMODE("X-MODE", "Ultra Turbo", "🔥", "performance", Color(0xFFFF1E42))
}

data class ToolDef(val id: String, val icon: String, val title: String)

object Tools {
    val toggles = listOf("touch", "dns", "thermal", "dnd", "bright", "eq", "angle")
    val all = listOf(
        ToolDef("ram", "🧹", "One-Tap RAM Cleaner"),
        ToolDef("touch", "👆", "Touch Response Booster"),
        ToolDef("dns", "🌐", "DNS Changer 1.1.1.1"),
        ToolDef("refresh", "🖥️", "Refresh Rate Lock"),
        ToolDef("thermal", "🌡️", "Thermal Throttling Guard"),
        ToolDef("dnd", "🔕", "Do Not Disturb"),
        ToolDef("bright", "🔆", "Brightness Lock"),
        ToolDef("eq", "🎧", "Audio Footstep EQ"),
        ToolDef("gyro", "🎯", "Gyroscope Calibrator"),
        ToolDef("time", "⏱️", "Game Time Tracker"),
        ToolDef("angle", "🧬", "ANGLE GPU Tweaker"),
        ToolDef("macro", "🖱️", "Macro Configurator")
    )
}
