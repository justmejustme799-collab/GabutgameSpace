package com.fanzy.gamespace.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Shape sudut miring: kiri-atas & kanan-bawah dipotong (chamfer). */
@Composable
fun rememberChamfer(cut: Dp): Shape {
    val px = with(LocalDensity.current) { cut.toPx() }
    return remember(px) {
        GenericShape { size, _ ->
            moveTo(px, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width, size.height - px)
            lineTo(size.width - px, size.height)
            lineTo(0f, size.height)
            lineTo(0f, px)
            close()
        }
    }
}

@Composable
fun ChamferCard(
    modifier: Modifier = Modifier,
    accent: Color = Fz.Red,
    cut: Dp = 14.dp,
    glow: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = rememberChamfer(cut)
    var m = modifier
    if (glow) m = m.shadow(14.dp, shape, ambientColor = accent, spotColor = accent)
    m = m.clip(shape)
        .background(Brush.linearGradient(listOf(Fz.Panel2, Fz.Panel)), shape)
        .border(1.dp, accent.copy(alpha = if (glow) 0.9f else 0.45f), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(modifier = m.padding(12.dp), content = content)
}

@Composable
fun GlowButton(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Fz.Red,
    enabled: Boolean = true,
    pulse: Boolean = true,
    onClick: () -> Unit
) {
    val shape = rememberChamfer(12.dp)
    val inf = rememberInfiniteTransition(label = "pulse")
    val a by inf.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseA"
    )
    val alpha = if (pulse && enabled) a else 0.6f
    val c = if (enabled) color else Fz.Dim
    Box(
        modifier = modifier
            .shadow(if (enabled) 12.dp else 0.dp, shape, ambientColor = c, spotColor = c)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(c, c.copy(alpha = 0.55f))), shape)
            .border(1.5.dp, Color.White.copy(alpha = alpha), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        T(text, 14, Color.White, FontWeight.Black, align = TextAlign.Center, spacing = 1.5f)
    }
}

fun DrawScope.arcRing(color: Color, start: Float, sweep: Float, stroke: Float, inset: Float) {
    drawArc(
        color = color,
        startAngle = start,
        sweepAngle = sweep,
        useCenter = false,
        topLeft = Offset(inset, inset),
        size = Size(size.width - inset * 2, size.height - inset * 2),
        style = Stroke(width = stroke, cap = StrokeCap.Round)
    )
}

/** Gauge dengan busur nilai animasi + ring berputar. */
@Composable
fun RotGauge(
    value: Float,
    centerText: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
    dimension: Dp = 96.dp
) {
    val v by animateFloatAsState(value.coerceIn(0f, 1f), tween(900), label = "gaugeV")
    val inf = rememberInfiniteTransition(label = "gaugeRot")
    val rot by inf.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(3500, easing = LinearEasing)),
        label = "rot"
    )
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(dimension), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 9.dp.toPx()
                val inset = sw / 2 + 6.dp.toPx()
                arcRing(Color.White.copy(alpha = 0.08f), 135f, 270f, sw, inset)
                arcRing(color, 135f, 270f * v, sw, inset)
                rotate(rot) {
                    arcRing(color.copy(alpha = 0.6f), 0f, 30f, 2.dp.toPx(), 2.dp.toPx())
                    arcRing(color.copy(alpha = 0.3f), 180f, 30f, 2.dp.toPx(), 2.dp.toPx())
                }
            }
            T(centerText, 15, Color.White, FontWeight.Black, mono = true)
        }
        T(label, 10, Fz.Dim, align = TextAlign.Center, mono = true)
    }
}
