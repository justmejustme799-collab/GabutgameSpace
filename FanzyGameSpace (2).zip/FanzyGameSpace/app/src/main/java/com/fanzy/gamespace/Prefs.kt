package com.fanzy.gamespace

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val DEV_PASSWORD = "FANZYDEV2026"
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("fanzy_prefs", Context.MODE_PRIVATE)
    }

    var tokens: Int
        get() = sp.getInt("tokens", 2)
        set(v) { sp.edit().putInt("tokens", v.coerceAtLeast(0)).apply() }

    var isVip: Boolean
        get() = sp.getBoolean("vip", false)
        set(v) { sp.edit().putBoolean("vip", v).apply() }

    var gamePkg: String
        get() = sp.getString("game", Games.list[0].pkg) ?: Games.list[0].pkg
        set(v) { sp.edit().putString("game", v).apply() }

    var macroDelay: Int
        get() = sp.getInt("macro_delay", 150)
        set(v) { sp.edit().putInt("macro_delay", v.coerceIn(50, 3000)).apply() }

    var macroCombo: Boolean
        get() = sp.getBoolean("macro_combo", false)
        set(v) { sp.edit().putBoolean("macro_combo", v).apply() }

    var gyroBias: String
        get() = sp.getString("gyro_bias", "") ?: ""
        set(v) { sp.edit().putString("gyro_bias", v).apply() }

    fun flag(key: String): Boolean = sp.getBoolean("f_$key", false)
    fun setFlag(key: String, value: Boolean) { sp.edit().putBoolean("f_$key", value).apply() }

    /** VIP = unlimited. Free user: kurangi 1 token. Return false kalau token habis. */
    fun consumeToken(): Boolean {
        if (isVip) return true
        if (tokens <= 0) return false
        tokens -= 1
        return true
    }

    fun addTokens(n: Int) { tokens += n }

    fun verifyDevKey(input: String): Boolean {
        if (input == DEV_PASSWORD) { isVip = true; return true }
        return false
    }
}
